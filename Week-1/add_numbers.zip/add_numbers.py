a = 2
b = 383

sum = a + b
print(sum)